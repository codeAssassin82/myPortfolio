<?php
 $detail_title 		= ( !empty($title)) 		? '<h3 class="content-head">'.$title.'</h3>':''; 
 $detail_des 		= ( !empty($description)) 	? '
	 <div class=" col-lg-12 hr-container"><hr class="vimeo-info-hr"></div>
	 <div class="col-lg-12 first-para"><p class="para-vimeo-info lusitana">'.strip_tags($description).'</p></div>':''; 
 $detail_client 	= ( !empty($client)) 		? '<div><span class="detail-span">Client:</span> <span class="dc-span">'.$client.'</span></div>':''; 
 $detail_website 	= ( !empty($website)) 		? '<div><span class="detail-span">Website:</span> <span class="dc-span">'.$website.'</span></div>':'';
 $detail_category 	= ( !empty($category)) 		? '<div><span class="detail-span">Category:</span> <span class="dc-span">'.$category.'</span></div>':'';
 $detail_skills 	= ( !empty($skills)) 		? '<div><span class="detail-span">Skills:</span> <span class="dc-span">'.$skills.'</span></div>':'';
 ?>

<!--VIMEO-->
<div class="xs-mobile mobile-align-center">
	<figure class="effect-bubba align-center">
		<img src="<?php echo esc_attr($thumbnail_attributes[0]); ?>" <?php print $alt;?> width="<?php echo esc_html($thumbnail_attributes[1]); ?>" height="<?php echo esc_html($thumbnail_attributes[2]); ?>"/>
        <figcaption class="align-center">
			<?php print $item_title; ?>
			<a class="col-lg-2 align-center btn-effect viewmore venoboxvid video-load-click" data-type="vimeo"  href="<?php echo esc_attr($vimeo_video);?>" target="_self"><span>View more</span></a>
		</figcaption>
	</figure>
</div>

<!-- VIMEO VIDEO TOGGLE CONTENT -->
<div class="vbox-video-content">
	<div class="video_content vimeo-info-font">
	<button type="button" class="close-vinfo-bt"><i class="fa fa-minus"></i></button>
		<div  class="wraper-video-content hide">	
			<?php print  $detail_title;?>
            
			<?php print $detail_des;?>
            
            <?php if ( !empty($detail_client) || !empty($detail_website) || !empty($detail_category) || !empty($detail_skills)) {?>	
			<div class=" col-lg-12 hr-container">
				<hr class="vimeo-info-hr">
			</div>
			<div class=" col-lg-12 lusitana detail-address">
				<?php print $detail_client;?>
                <?php print $detail_website;?>
                <?php print $detail_category;?>
                <?php print $detail_skills;?>
			</div>
            <?php }?>
		</div>
	</div>
</div>
<!-- /VIMEO VIDEO TOGGLE CONTENT -->
<!--/VIMEO-->