<?php
/**
 *
 * VC COLUMN and VC COLUMN INNER
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function mi_column_n( $atts, $content = '', $id = '' ) { 
	extract( shortcode_atts( array(
		'id'                => '',
		'class'             => '',
		'css'			    => '',
		'video_bg'		    => '',
		'mp4_video_url'		=> '',
		'ogg_video_url'		=> '',
		'type_bg'			=> '',
		'bg_slider_images'	=> '',
		'full_section'   	=> '',
		'full_width'     	=> ''
	), $atts ) );
	
	$website_style = cs_get_option( 'website_style' );
	if ($website_style == 'website-1' ) {

		$first = strpos($css, "{");
		$second = substr($css, $first+1);
		$styles = explode("}", $second);
		if (!empty($css)){ $styles = 'style="'.$styles[0].'"';} else {$styles = '';}
		
		if ($full_width == 'stretch_row') { $fwidth = 'container-full';} else {$fwidth = '';}
	
		$output  = '<div class="container '.$fwidth.' row_wrap '.vc_shortcode_custom_css_class( $css, ' ' ).'" '.$styles.'>';
		$output .= do_shortcode($content); 
		$output .= '</div>';
		return $output;
	
	} elseif ($website_style == 'website-2' ) {

	$first = strpos($css, "{");
	$second = substr($css, $first+1);
	$styles = explode("}", $second);
	if (!empty($css)){ $styles = 'style="'.$styles[0].'"';} else {$styles = '';}
	
	if ($full_width == 'stretch_row') { $fwidth = 'container-full';} else {$fwidth = '';}
	
	$meta_data 		= get_post_meta( get_the_ID(), '_custom_page_side_options', true );
	if (isset($meta_data['page_types'][0])) {
		$page_type 		= $meta_data['page_types'][0];
	} else {
		$page_type 		= '';
	}
	if ($page_type == 'slide_page'){
	
		$output  = '<div class="slider-page-inner '.vc_shortcode_custom_css_class( $css, ' ' ).'" '.$styles.'>';
		$output .= do_shortcode($content); 
		$output .= '</div>';

	} else {
		
		$output  = '<div class="container '.$fwidth.' row_wrap '.vc_shortcode_custom_css_class( $css, ' ' ).'" '.$styles.'>';
		$output .= do_shortcode($content); 
		$output .= '</div>';
		
	}
	
	return $output;

	} elseif ($website_style == 'website-3' || $website_style == 'website-4' || $website_style == 'website-5') {

	$first = strpos($css, "{");
	$second = substr($css, $first+1);
	$styles = explode("}", $second);
	if (!empty($css)){ $styles = 'style="'.$styles[0].'"';} else {$styles = '';}

	$mp4_video	= ( !empty($mp4_video_url)) ? '<source src="'.$mp4_video_url.'" type="video/mp4">':'';
	$ogg_video	= ( !empty($ogg_video_url)) ? '<source src="'.$ogg_video_url.'" type="video/ogg">':'';

	$output  =  '<div class="vc_row wpb_row vc_row-fluid" '.$styles.'>';

	
	if ($type_bg == 'video_bg') {
	
	/*Video background*/	
		global $imageShortcode1;
		$imageShortcode1++;
		$image_info_id1 =  $imageShortcode1;
	    
        $output .=  '<video id="video_'.$image_info_id1.'" class="video-wrap" preload="auto" autoplay loop muted >';
	    $output .=  $mp4_video;
	    $output .=  $ogg_video;
	    $output .=  'your browser does not support HTML5';
	    $output .=  '</video>';
	    $output .=  '<div class="opacity-bg"></div>';
	
    	$output .=  do_shortcode($content);
	/*End Video background*/	
	
	} else if ($type_bg == 'slider_bg'){
	
	/*Slider background*/	 
		//Get image ID
		if( ! function_exists('mi_is_explodable' ) ) {
			function mi_is_explodable( $bg_slider_images ) {
				return (strpos($bg_slider_images, ',') === false ) ? false : true;
			}  
		}
		
		if ($bg_slider_images) {
			$is_explode_images = mi_is_explodable($bg_slider_images);
			if ($is_explode_images || is_numeric($bg_slider_images) ) {
				$exploded_images = explode(',', $bg_slider_images); 
			}
		}
		
		$output .=  '<div class="slider-bg-wrap">';
		$output .=  '<div class="owl-carousel bg-slider">';
			
			foreach ($exploded_images as $image) : 
			$attachment_id = $image;
			$image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
			$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
				$output .=  '<img src="'.$image_attributes[0].'" alt="'.$thumbnail_alt.'"/>';
			endforeach;

    	$output .=  '</div>';
		
		$output .=  do_shortcode($content);
		
		
		$output .=  '<i class="customNextBtn fa fa-2x fa-chevron-right"></i>';
		$output .=  '<i class="customPrevBtn fa fa-2x fa-chevron-left"></i>';
		
		$output .=  '</div>';
    
	/*End Slider background*/	
		
	} else {
		
		$output .=  do_shortcode($content); 
	
	}
	
	
	$output .=  '</div>';

	return $output;

	}
}

function mi_column_inner( $atts, $content = '', $id = '' ) { 
	extract( shortcode_atts( array(
		'font_color'      => '',
		'el_class' => '',
		'width' => '1/1',
		'css' => '',
		'offset' => ''
	), $atts ) );


	$first = strpos($css, "{");
	$second = substr($css, $first+1);
	$styles = explode("}", $second);
	if (!empty($css)){ $styles = 'style="'.$styles[0].'"';} else {$styles = '';}

	$width = wpb_translateColumnWidthToSpan($width);
	$width = vc_column_offset_class_merge($offset, $width);
	
	$output  = '<div class="full-inner '.$width.'" '.$styles.'>';
	$output .= do_shortcode($content); 
	$output .= '</div>';
	
	return $output;

}

function mi_row_inner( $atts, $content = '', $id = '' ) {
	
	$output  = '<div class="vc_row wpb_row vc_inner vc_row-fluid">';
	$output .= do_shortcode($content); 
	$output .= '</div>';
	
	return $output;
}

add_shortcode('vc_row', 'mi_column_n');
add_shortcode('vc_column', 'mi_column_inner');
add_shortcode('vc_row_inner', 'mi_row_inner');