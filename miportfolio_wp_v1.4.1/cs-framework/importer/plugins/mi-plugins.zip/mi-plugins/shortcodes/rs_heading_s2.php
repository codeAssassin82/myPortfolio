<?php
/**
 *
 * Heading
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_heading_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'heading'         => '',
    'description'     => '',
    'title_color'     => '',
  	'desc_color'	  => '',
  	'sep_color'	 	  => '',
	'title_font_size' => '',
	'desc_font_size'  => '',
	
  ), $atts ) );

  $title_font_size	= ( !empty($title_font_size)) ? 'font-size: '.$title_font_size.';':'';
  $desc_font_size	= ( !empty($desc_font_size)) ? 'font-size: '.$desc_font_size.';':'';
  $title_color		= ( !empty($title_color)) ? 'color: '.$title_color.';':'';
  $desc_color		= ( !empty($desc_color)) ? 'color: '.$desc_color.';':'';
  
  
  if (!empty($title_color) || !empty($title_font_size)) {$tcolor = 'style="'.$title_color.' '.$title_font_size.'"';} else {$tcolor = '';}
  if (!empty($desc_color) || !empty($desc_font_size))   {$tdesc_color = 'style="'.$desc_color.' '.$desc_font_size.'"';} else {$tdesc_color = '';}


  if (!empty($sep_color))  	{$tsep_color = 'style="background-color:'.$sep_color.'"';} else {$tsep_color = '';}
  if (!empty($description)) {$content_is = '<h4 '.$tdesc_color.'>'.$description.'</h4>';} else {$content_is = '';}
  if (!empty($heading)) 	{$heading_is = '<h3 '.$tcolor.'>'.$heading.'</h3><div class="hr-seperator align-center" '.$tsep_color.'></div>';} else {$heading_is = '';}

	$output    =  '<div class="align-center heading-wrap">';
	$output   .=  $heading_is;
	$output   .=  $content_is;
	$output   .=  '</div>';

	return $output;

}
add_shortcode( 'mi_heading_s2', 'mi_heading_s2' );
