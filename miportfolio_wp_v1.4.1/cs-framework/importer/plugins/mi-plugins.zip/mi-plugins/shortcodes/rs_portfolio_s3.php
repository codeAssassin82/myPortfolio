<?php
/**
 *
 * RS Portfolio Style 3
 * @since 1.0.0
 * @version 1.1.0
 *
 */

function mi_portfolio_s3( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              		=> '',
    'class'         	  	=> '',
	'type'      	    	=> '',
	'thumbnail'          	=> '',
	'title'           		=> '',
	'carusel_slider_images' => '',
	'description'           => '',
	'client'           		=> '',
	'website'           	=> '',
	'category'           	=> '',
	'skills'           		=> '',
	'vimeo_video'           => '',
  ), $atts ) );


	$item_title	= ( !empty($title)) ? '<h2>'.$title.'</h2>':''; 
	
	$thumbnail_id = $thumbnail;
	$thumbnail_attributes = wp_get_attachment_image_src( $thumbnail_id, 'full' );
	$thumbnail_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
	$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; 

	ob_start();


	global $imageShortcode;
	$imageShortcode++;
	$image_info_id =  $imageShortcode; ?>
	
    <div class="portfolio-item-wrap">
	
	<?php
	$website_style = cs_get_option( 'website_style' );
	if ($website_style == 'website-3' || $website_style == 'website-4' || $website_style == 'website-5') {

		if ($type == 'carousel_slider') 	{	require('portfolio/inc_carousel_slider_s3.php');	
		} elseif ($type == 'vimeo_video') 	{	require('portfolio/inc_vimeo_video_s3.php');
		} elseif ($type == 'flex_slider') 	{	require('portfolio/inc_flex_slider_s3.php');
		} elseif ($type == 'image-gallery') { 	require('portfolio/inc_image_gallery_s3.php');
		} elseif ($type == 'image_info') 	{ 	require('portfolio/inc_info_s3.php');}
	
	} else {
		print "<div class='section-alert'>This unit is not supported by the chosen style of the site. Please replace this unit in the control panel.</div>";
	}
	?>
	</div>
    
	<?php return ob_get_clean();
}
add_shortcode( 'mi_portfolio_s3', 'mi_portfolio_s3' );
