<?php
/**
 *
 * RS Portfolio
 * @since 1.0.0
 * @version 1.1.0
 *
 */


function mi_portfolio_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              		=> '',
    'class'         	  	=> '',
  ), $atts ) );

	$output    =  '<section class="sec_2 '.$class.'">';
	$output   .=  do_shortcode($content);
	$output   .=  '</section>';


	return $output;
}
add_shortcode( 'mi_portfolio_s2', 'mi_portfolio_s2' );


function mi_portfolio_item_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              		=> '',
    'class'         	  	=> '',
	'type'      	    	=> '',
	'thumbnail'          	=> '',
	'title'           		=> '',
	'carusel_slider_images' => '',
	's_description'			=> '',
	'description'           => '',
	'client'           		=> '',
	'website'           	=> '',
	'category'           	=> '',
	'skills'           		=> '',
	'vimeo_video'           => '',
  ), $atts ) );


	$item_title	= ( !empty($title)) ? '<h3>'.$title.'</h3>':''; 
	
	$thumbnail_id = $thumbnail;
	$thumbnail_attributes = wp_get_attachment_image_src( $thumbnail_id, 'full' );
	$thumbnail_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
	$alt = ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; 
	
	ob_start();
		
	global $imageShortcode;
	$imageShortcode++;
	$image_info_id =  $imageShortcode;
	?>
	
	<div class="portfolio-wrap">
    	 <?php
			if ($type == 'carousel_slider')		{	require('inc_carousel_slider.php');			
			} elseif ($type == 'vimeo_video')	{	require('inc_vimeo_video.php');
			} elseif ($type == 'flex_slider')	{	require('inc_flex_slider.php');
			} elseif ($type == 'image-gallery')	{	require('inc_image_gallery.php');
			} elseif ($type == 'image_info')	{	require('inc_info.php');}
		 ?>
	</div>
	
	<?php return ob_get_clean();
}
add_shortcode( 'mi_portfolio_item_s2', 'mi_portfolio_item_s2' );