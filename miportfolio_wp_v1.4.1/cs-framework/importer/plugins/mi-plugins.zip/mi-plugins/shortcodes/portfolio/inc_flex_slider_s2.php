<?php
 $detail_title 		= ( !empty($title)) 		? '<h3 class="content-head">'.$title.'</h3>':''; 
 $s_description		= ( !empty($s_description)) ? '<hr/><h4 class="lusitana p-intro-text">'.$s_description.'</h4>':'';
 $thumbnail_url		= ( !empty($thumbnail)) 	? 'style="background-image:url('.$thumbnail_attributes[0].');"':''; 
 $detail_des 		= ( !empty($description)) 	? '<h4>'.strip_tags($description).'</h4>':''; 


 if( ! function_exists('mi_is_explodable' ) ) {
  function mi_is_explodable( $carusel_slider_images ) {
    return (strpos($carusel_slider_images, ',') === false ) ? false : true;
  }  
}

?>
<!-- FLEX SLIDER -->
<div class="portfolio wow fadeInUp animated" data-wow-duration="2s" data-wow-delay="0.2s" <?php print $thumbnail_url;?>>
    <div class="thumb_title notag"></div>
    <div class="inner-carousal-slider pop-up-block align-center col-lg-6 col-md-6 col-sm-8 col-xs-10">
        <div class="col-lg-10 align-center">
            <?php print $item_title; ?>
            <?php print $s_description; ?>
            <div class="btn-sec align-center">
                <button class="col-lg-2 btn-effect viewmore align-center load-flex-slider"  data-toggle="modal">View More</button>
            </div>
        </div>
    </div>
</div>


<!--FLEX SLIDER POPUP -->
<!-- modal -->
<div class="modal fade myLargeModal" tabindex="-1" role="dialog" aria-hidden="true">
    <!-- modal-dialog -->
    <div class="modal-dialog modal-lg">
        <!--modal-content -->
        <div class="modal-content">
            <div class="modal-body">
                <section class="sec_4 container padding-left0 padding-right" >
                
                    <div class="owl-carousel-flex flex-screen-slider">
                        <?php
                        if ($carusel_slider_images) {
                            $is_explode_images = mi_is_explodable($carusel_slider_images);
                            if ($is_explode_images || is_numeric($carusel_slider_images) ) {
                              $exploded_images = explode(',', $carusel_slider_images); 
                        
                                  foreach ($exploded_images as $image) : 
                                  
                                    $attachment_id = $image;
                                    $image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
									$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
									$alt = ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; ?>
                                    
                                    	<img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> />
                    
                                  <?php endforeach;
                            }
                        }
                        ?>
                    </div>
                                            
                                            
                    <div class="flex-text">
                        <div class="col-lg-10 align-center">
                            <?php print $detail_title;?>
                            <div class="col-lg-4 col-md-4 col-sm-4 seperator align-center"></div>
                            <?php print $detail_des ;?>
                        </div>
                    </div>
                </section>
            </div>
            <a href="#p-flex-slider" class="black-close close-flex-slider" data-dismiss="modal"><i class="fa fa-times"></i></a>
        </div>
        <!-- /modal-content -->
    </div>
    <!-- /modal-dialog -->
</div>
<!-- /modal -->
<!--/FLEX SLIDER POPUP  -->