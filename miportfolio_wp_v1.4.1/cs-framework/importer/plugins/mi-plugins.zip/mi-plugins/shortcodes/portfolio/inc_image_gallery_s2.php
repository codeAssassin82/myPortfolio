<?php
 $s_description		= ( !empty($s_description)) ? '<hr/><h4 class="lusitana p-intro-text">'.$s_description.'</h4>':'';
 $thumbnail_url		= ( !empty($thumbnail)) 	? 'style="background-image:url('.$thumbnail_attributes[0].');"':''; 
 $detail_des 		= ( !empty($description)) 	? '<h4>'.$description.'</h4>':''; 

 if( ! function_exists('mi_is_explodable' ) ) {
  function mi_is_explodable( $carusel_slider_images ) {
    return (strpos($carusel_slider_images, ',') === false ) ? false : true;
  }  
}

?>
<!--IMAGE GALLERY  -->
<div class="portfolio" <?php print $thumbnail_url;?>>
    <div class="thumb_title notag"></div>
    <div class="inner-carousal-slider pop-up-block align-center col-lg-6 col-md-6 col-sm-8 col-xs-10">
        <div class="col-lg-10 align-center">
            <?php print $item_title; ?>
            <?php print $s_description;?>
        </div>
        <!--grid-gallery -->
        <div id="grid-gallery-<?php print $image_info_id;?>" class="grid-gallery">
            <!-- grid-wrap -->
            <section class="grid-wrap">
                <div class="grid">
                    <div class="btn-sec align-center">
                        <a class="col-lg-2 btn-effect viewmore align-center load-grid-gallery">View More</a>
                    </div>
                </div>
            </section>
            <!-- /grid-wrap -->
            
            <!-- slideshow -->
            <section class="slideshow">
                <ul>
                    <?php
                    if ($carusel_slider_images) {
                        $is_explode_images = mi_is_explodable($carusel_slider_images);
                        if ($is_explode_images || is_numeric($carusel_slider_images) ) {
                          $exploded_images = explode(',', $carusel_slider_images); 
                    
                              foreach ($exploded_images as $image) : 
                              
                                $attachment_id = $image;
                                $image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
								$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
								$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':'';
                                $image_title = get_post($attachment_id)->post_title;
                                $image_ciption = get_post($attachment_id)->post_excerpt;
                                ?>

                                <li>
                                    <figure>
                                        <figcaption>
                                            <?php if (!empty($image_title)){ print '<h3>'.$image_title.'</h3>';}?>
                                            <hr/>
                                            <?php if (!empty($image_ciption)){ print '<p>'.$image_ciption.'</p>';}?>
                                        </figcaption>
                                        
                                        <img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> />
                                        
                                    </figure>
                                </li>

                              <?php endforeach;
                        }
                    }
                    ?>

                </ul>
                <nav>
                <span class="nav-prev fa-chevron-left fa fa-2x "></span>
                <span class="nav-next fa-chevron-right fa fa-2x"></span>
                <span class="close nav-close"><i class="fa fa-times"></i></span>
                </nav>
            </section>
            <!-- /slideshow -->
        </div>
        <!--/grid-gallery -->	
    </div>
</div>
<!--/IMAGE GALLERY  -->