<?php
	$detail_title 		= ( !empty($title)) 		? '<h3>'.$title.'</h3>':''; 
	$thumbnail_url		= ( !empty($thumbnail)) 	? 'style="background-image:url('.$thumbnail_attributes[0].');"':''; 
	$s_description		= ( !empty($s_description)) ? '<hr/><h4 class="lusitana p-intro-text">'.$s_description.'</h4>':''; 
	$detail_des 		= ( !empty($description)) 	? '<h4>'.strip_tags($description).'</h4>':''; 
	$detail_client 		= ( !empty($client)) 		? '<div><span class="detail-span">Client:</span> <span class="dc-span">'.$client.'</span></div>':''; 
	$detail_website 	= ( !empty($website)) 		? '<div><span class="detail-span">Website:</span> <span class="dc-span">'.$website.'</span></div>':'';
	$detail_category 	= ( !empty($category)) 		? '<div><span class="detail-span">Category:</span> <span class="dc-span">'.$category.'</span></div>':'';
	$detail_skills 		= ( !empty($skills)) 		? '<div><span class="detail-span">Skills:</span> <span class="dc-span">'.$skills.'</span></div>':'';
 
  if( ! function_exists('mi_is_explodable' ) ) {
	  function mi_is_explodable( $carusel_slider_images ) {
			return (strpos($carusel_slider_images, ',') === false ) ? false : true;
	  }  
  }
 
 ?>
 
 
<!--IMAGES & INFO  -->
<div class="portfolio wow fadeInUp animated" data-wow-duration="2s" data-wow-delay="0.2s" <?php print $thumbnail_url;?>>
    <div class="thumb_title notag"></div>
    <div class="inner-carousal-slider pop-up-block align-center col-lg-6 col-md-6 col-sm-8 col-xs-10">
        <div class="col-lg-10 align-center">
            <?php print $item_title; ?>
            <?php print $s_description; ?>
            <div class="btn-sec align-center">
                <button class="col-lg-2 btn-effect viewmore align-center" data-toggle="modal" data-target="#image_info_<?php print $image_info_id;?>">View More</button>
            </div>
        </div>
    </div>
</div>
<!-- modal -->
<div class="modal fade" id="image_info_<?php print $image_info_id;?>" tabindex="-1" role="dialog" aria-hidden="true">
    <!-- modal-dialog -->
    <div class="modal-dialog modal-lg">
        <!-- modal-content -->
        <div class="modal-content">
            <div class="modal-body">
                <div class="image-n-info">
                    <div class="container padding-left0 padding-right">
                        <div class="col-lg-3 col-md-4 col-sm-4" id="image_info<?php print rand(2365, 123987);?>">
                            <div class="image-info">
                                <?php print $detail_title;?>
                                <hr/>
                                <?php print $detail_des;?>
                                <hr/>
                                
                                <?php if ( !empty($detail_client) || !empty($detail_website) || !empty($detail_category) || !empty($detail_skills)) {?>	
                                <div class="col-lg-12 lusitana detail-address padding-none">
                                    <?php print $detail_client;?>
                                    <?php print $detail_website;?>
                                    <?php print $detail_category;?>
                                    <?php print $detail_skills;?>
                                </div>
                                <?php }?>
                            </div>
                        </div>
                        <div class="col-lg-9 col-md-8 col-sm-8 padding-right">
                            <?php
                                if ($carusel_slider_images) {
                                    $is_explode_images = mi_is_explodable($carusel_slider_images);
                                    if ($is_explode_images || is_numeric($carusel_slider_images) ) {
                                      $exploded_images = explode(',', $carusel_slider_images); 
                                
                                          foreach ($exploded_images as $image) : 
                                          
                                            $attachment_id = $image;
                                            $image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
											$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
											$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; ?>
            
											<img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> />
    
                                          <?php endforeach;
    
                                    }
                                }
                                ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <button type="button" class="black-close" data-dismiss="modal"><i class="fa fa-times"></i></button>
        </div>
        <!-- /modal-content -->
    </div>
    <!-- /modal-dialog -->
</div>
<!-- /modal -->
<!--/IMAGES & INFO  -->