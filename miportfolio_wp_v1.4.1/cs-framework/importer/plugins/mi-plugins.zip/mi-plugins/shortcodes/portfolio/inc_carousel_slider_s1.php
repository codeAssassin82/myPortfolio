<?php
	$detail_title 		= ( !empty($title)) 		? '<h3 class="content-head">'.$title.'</h3>':''; 
	$thumbnail_url		= ( !empty($thumbnail)) 		? 'style="background-image:url('.$thumbnail_attributes[0].');"':''; 
	$s_description		= ( !empty($s_description)) ? '<hr/><h4 class="lusitana p-intro-text">'.$s_description.'</h4>':''; 
	$detail_des 		= ( !empty($description)) 	? '
		<div class=" col-lg-12 hr-container"><hr class="vimeo-info-hr"></div>
		<div class="col-lg-12 first-para"><p class="para-vimeo-info lusitana">'.strip_tags($description).'</p></div>':''; 
	$detail_client 	= ( !empty($client)) 		? '<div><span class="detail-span">Client:</span> <span class="dc-span">'.$client.'</span></div>':''; 
	$detail_website 	= ( !empty($website)) 		? '<div><span class="detail-span">Website:</span> <span class="dc-span">'.$website.'</span></div>':'';
	$detail_category 	= ( !empty($category)) 		? '<div><span class="detail-span">Category:</span> <span class="dc-span">'.$category.'</span></div>':'';
	$detail_skills 	= ( !empty($skills)) 		? '<div><span class="detail-span">Skills:</span> <span class="dc-span">'.$skills.'</span></div>':'';


	 if( ! function_exists('mi_is_explodable' ) ) {
	  function mi_is_explodable( $carusel_slider_images ) {
		return (strpos($carusel_slider_images, ',') === false ) ? false : true;
	  }  
	}
	
	if ($carusel_slider_images) {
		$is_explode_images = mi_is_explodable($carusel_slider_images);
		if ($is_explode_images  || is_numeric($carusel_slider_images) ) {
		  $exploded_images = explode(',', $carusel_slider_images); 
		}
	}

?>

<!-- CAROUSAL SLIDER -->
<div class="portfolio wow fadeInUp animated" data-wow-duration="2s" data-wow-delay="0.2s" <?php print $thumbnail_url;?>>
    <div class="thumb_title notag"></div>
    <div class="inner-carousal-slider pop-up-block align-center col-lg-6 col-md-6 col-sm-8 col-xs-10" >
        <div class="col-lg-10 align-center">
            <?php print $item_title; ?>
            <?php print $s_description;?>
            <div class="btn-sec align-center">
                <a class="trigger-overlay col-lg-2 btn-effect viewmore align-center">View More</a>
            </div>
        </div>
    </div>
</div>

<div class="overlay1 overlay-scale">
    
    <!-- Carousal info open/close -->
    <button type="button" class="overlay-close close"><i class="fa fa-times"></i></button>
    <button type="button" class="slider-info"><i class="fa fa-plus"></i></button>
    
    <!-- Carousal images -->
    <div class="owl-carousel full-screen-slider">
        <?php
        foreach ($exploded_images as $image) : 
            $attachment_id = $image;
            $image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
			$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
			$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; ?>
			
				<div><img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> /></div>

        <?php endforeach; ?>
    </div>

    
</div>

<!-- SLIDER TOGGLE CONTENT -->
<div class="slider-video-content">

    <div class="vimeo-info-font hidden slider_content">
    <button type="button" class="close-info-bt"><i class="fa fa-minus"></i></button>
        <div  class="wraper-slider-content hide ">	
            <?php print $detail_title;?>
            <?php print $detail_des;?>
            
            <?php if ( !empty($detail_client) || !empty($detail_website) || !empty($detail_category) || !empty($detail_skills)) {?>
            <div class=" col-lg-12 hr-container">
                <hr class="vimeo-info-hr">
            </div>

            <div class=" col-lg-12 lusitana detail-address">
                <?php print $detail_client;?>
                <?php print $detail_website;?>
                <?php print $detail_category;?>
                <?php print $detail_skills;?>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- /SLIDER TOGGLE CONTENT -->
<!-- /CAROUSAL SLIDER -->
