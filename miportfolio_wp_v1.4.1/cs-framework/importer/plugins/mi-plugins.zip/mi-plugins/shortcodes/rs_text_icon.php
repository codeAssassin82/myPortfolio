<?php
/**
 *
 * Text with icon
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_text_icon( $atts, $content = '', $id = '' ) {
  
  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'title'           => '',
	'icon'            => '',
	'icon_color'      => '',
	'description'     => '',
	'icon_position'   => '',
  ), $atts ) );

  $icon_color		= ( !empty($icon_color)) ? 'style="color:'.$icon_color.';"':'';

    if ($icon_position == 'left') {
    	
    	$description	= ( !empty($description)) ? '<div class="expl-text lusitana">'.$description.'</div>':'';
    	$title			= ( !empty($title)) ? '<h3 class="icons-text">'.$title.'</h3>':'';
    	
        $output  =  '<div class="mobile-about-me about_intro about-me">';
        $output .=  '<div class="col-lg-4 col-md-5 col-sm-3 col-xs-3 padding-none"><span class="'.$icon.' icons-edit-about" '.$icon_color.'></span></div>';
        $output .=  '<div class="col-lg-7 col-md-7 col-sm-9 col-xs-9 text-left small-center wow fadeIn animated animated">';
        $output .=  $title;
        $output .=  $description;
        $output .=  '</div>';
        $output .=  '<div class="clearfix"></div>';
        $output .=  '</div>';

    } else {
    	
    	$description	= ( !empty($description)) ? ' <p class="expl-text lusitana align-center">'.$description.'</p>':'';
    	$title 			= ( !empty($title)) ? '<h3 class="icon-tag">'.$title.'</h3>':'';

        $output  =  '<div class="icons-row-1 wow fadeIn animated animated">';
        $output .=  '<div class="'.$icon.' icons-edit icons-edit-expertise align-center" '.$icon_color.'></div>';
        $output .=  $title;
        $output .=  $description;
        $output .=  '</div>';

    }

  return $output;

}
add_shortcode( 'mi_text_icon', 'mi_text_icon' );
