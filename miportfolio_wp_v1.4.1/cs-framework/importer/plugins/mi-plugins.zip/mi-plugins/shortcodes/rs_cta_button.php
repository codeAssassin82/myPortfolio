<?php
/**
 *
 * CALL TO ACTION BUTTON
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_cta_button( $atts, $content = '', $id = '' ) {
  
  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'description'     => '',
	'label'           => '',
	'target'          => '',
	'link'            => '',
  ), $atts ) );

	$description	= ( !empty($description)) ? '<p class="intro align-center sc-website-style3">'.$description.'</p>':'';
	if ($target == 'blank') {$target_blank = 'target="_blank"';} else {$target_blank = 'target="_self"';}
	
	$output	 = $description;
	$output	.= '<div class="col-lg-6 btn-sec align-center">';
	$output	.= 	'<a class=" col-lg-2 downld-resume lusitana btn-effect-resume align-center" '.$target_blank.' href="'.$link.'">'.$label.'</a>';
	$output	.= 	'</div>';

  return $output;

}
add_shortcode( 'mi_cta_button', 'mi_cta_button' );
