<?php
/**
 *
 * Contact info
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_contact_info( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
  	'title'           => '',
  	'link'            => '',
  	'label'           => '',
  	'target'          => '',
  	'align'           => '',
  ), $atts ) );

	$website_style = cs_get_option( 'website_style' );
	if ($website_style == 'website-2') {
		$output    =  "<div class='section-alert'>This unit is not supported by the chosen style of the site. Please replace this unit in the control panel.</div>";
	} else {

    if ($target == 'blank') {$target_blank = 'target="_blank"';} else {$target_blank = '';}
    if ($align == 'center') {$align = 'align-center';} else {$align = '';}

    $output	= '<div class="contact-info '.$align.'"><p>'.$title.'';
    if (!empty($link)){
    	$output	.= '<a href="'. $link .'" '.$target_blank.'> '.$label.'</a>';
    } else {
    	$output	.= $label;
    } 
    $output	.= '</p></div>';

	}

  return $output;

}
add_shortcode( 'mi_contact_info', 'mi_contact_info' );
