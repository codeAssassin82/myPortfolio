<?php
 $detail_title 		= ( !empty($title)) 		? '<h3>'.$title.'</h3>':''; 
 $detail_des 		= ( !empty($description)) 	? '<h4>'.$description.'</h4>':''; 

 //Get image ID
 if( ! function_exists('mi_is_explodable' ) ) {
  function mi_is_explodable( $carusel_slider_images ) {
    return (strpos($carusel_slider_images, ',') === false ) ? false : true;
  }  
 }
?>
<!--GRID GALLERY SLIDER-->
	<!--GRID-GALLERY -->
	<div class="grid-gallery" id="grid-gallery-<?php echo esc_html($image_info_id);?>">
		<!-- GRID-WRAP -->
		<section class="grid-wrap">
			<div class="grid">
				<div class="btn-sec align-center">
					<figure class="effect-bubba align-center">
						<img src="<?php echo esc_attr($thumbnail_attributes[0]); ?>" <?php print $alt;?> width="<?php echo esc_html($thumbnail_attributes[1]); ?>" height="<?php echo esc_html($thumbnail_attributes[2]); ?>"/>
						<figcaption class="align-center">
						<?php print $item_title; ?>
						<a class="col-lg-2 align-center btn-effect viewmore load-grid-gallery"><span>View More</span></a>
						</figcaption>
					</figure>
				</div>
			</div>
		</section>
		<!-- /GRID-WRAP -->
        
		<!-- SLIDSHOW -->
		<section class="slideshow">
			<ul>
				<?php
                if ($carusel_slider_images) {
                    $is_explode_images = mi_is_explodable($carusel_slider_images);
                    if ($is_explode_images || is_numeric($carusel_slider_images) ) {
                      $exploded_images = explode(',', $carusel_slider_images); 
                
                          foreach ($exploded_images as $image) : 
                          
                            $attachment_id = $image;
                            $image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
							$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
							$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; 
                            $image_title = get_post($attachment_id)->post_title;
                            $image_ciption = get_post($attachment_id)->post_excerpt;
                            ?>

                            <li>
                                <figure>
                                    <figcaption>
                                        <?php if (!empty($image_title)){ print '<h3>'.$image_title.'</h3>';}?>
                                        <hr/>
                                        <?php if (!empty($image_ciption)){ print '<p>'.$image_ciption.'</p>';}?>
                                    </figcaption>
                                    <img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> />
                                    
                                </figure>
                            </li>

                          <?php endforeach;
            
                    }
                }
                ?>

			</ul>
			<nav>
			<span class="nav-prev fa-chevron-left fa fa-2x "></span>
			<span class="nav-next fa-chevron-right fa fa-2x"></span>
			<span class="close nav-close"><i class="fa fa-times"></i></span>
			</nav>
		</section>
		<!-- /SLIDSHOW -->
	</div>
	<!--/GRID-GALLERY-->						
<!--/GRID GALLERY SLIDER-->
