<?php
/**
 *
 * Fullscreen Landing
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_fullscreen_landing_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'title'           => '',
	'description'     => '',
	'bg_image'		  => '',
  ), $atts ) );

  ob_start(); 
  
	$thumbnail_attributes = wp_get_attachment_image_src( $bg_image, 'full' );
	
	$bg_image	= ( !empty($bg_image)) ? 'style="background-image: url('.$thumbnail_attributes[0].')"':'';
	?>
  
    <!-- LANDING SECTION -->
    <section class="autoheight sec_1">
        <div class="animate-landing" <?php print $bg_image;?>></div>
        <div class="col-lg-12 landing-text-pos wow fadeInUp animated" data-wow-duration="1s" data-wow-delay="3s">
            <?php if (!empty($title)) {?>
                <span class="landing-pname align-center"><?php echo esc_html($title);?></span>
                <hr id="title_hr">
            <?php }?>
            <?php if (!empty($description)) {?>
                <span class="col-lg-6 landing-intro align-center lusitana"><?php echo esc_html($description);?></span>
            <?php }?>
        </div>
    </section>
    <!-- /LANDING SECTION -->
    
	<?php return ob_get_clean();

}
add_shortcode( 'mi_fullscreen_landing_s2', 'mi_fullscreen_landing_s2' );
