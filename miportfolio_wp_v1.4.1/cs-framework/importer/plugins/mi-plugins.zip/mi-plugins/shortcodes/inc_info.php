<?php
 $detail_title 		= ( !empty($title)) 		? '<h3>'.$title.'</h3>':''; 
 $detail_des 		= ( !empty($description)) 	? '<h4 class="info-text">'.$description.'</h4>':''; 
 $detail_client 	= ( !empty($client)) 		? '<div><span class="detail-span">Client:</span> <span class="dc-span">'.$client.'</span></div>':''; 
 $detail_website 	= ( !empty($website)) 		? '<div><span class="detail-span">Website:</span> <span class="dc-span">'.$website.'</span></div>':'';
 $detail_category 	= ( !empty($category)) 		? '<div><span class="detail-span">Category:</span> <span class="dc-span">'.$category.'</span></div>':'';
 $detail_skills 	= ( !empty($skills)) 		? '<div><span class="detail-span">Skills:</span> <span class="dc-span">'.$skills.'</span></div>':'';
 
  //Get image ID
  if( ! function_exists('mi_is_explodable' ) ) {
	  function mi_is_explodable( $carusel_slider_images ) {
			return (strpos($carusel_slider_images, ',') === false ) ? false : true;
	  }  
  }
 
 ?>
 

<!--IMAGE INFO-->
<div class="xs-mobile mobile-align-center">
	<figure class="effect-bubba align-center">
		<img src="<?php echo esc_attr($thumbnail_attributes[0]); ?>" <?php print $alt;?> width="<?php echo esc_html($thumbnail_attributes[1]); ?>" height="<?php echo esc_html($thumbnail_attributes[2]); ?>"/>
        <figcaption class="align-center">
			<?php print $item_title; ?>
			<button class="col-lg-2 align-center btn-effect viewmore" data-toggle="modal" data-target="#image_info_<?php print $image_info_id;?>"><span>View more</span></button>
		</figcaption>
	</figure>
</div>
<!-- modal -->
<div class="modal fade" id="image_info_<?php echo $image_info_id;?>" tabindex="-1" role="dialog" aria-hidden="true">
	
	<!-- modal-dialog -->
	<div class="modal-dialog modal-lg">
		
		<!-- modal-content -->
		<div class="modal-content">
			<div class="modal-body">
				<div class="image-n-info">
					<div class="container padding-left0 padding-right">
						<div class="col-lg-3 col-md-4 col-sm-4" id="image_info1">
							<div class="image-info">
								<?php print $detail_title;?>
								<hr/>
								<?php print $description;?>
								<hr/>
                                
								<?php if ( !empty($detail_client) || !empty($detail_website) || !empty($detail_category) || !empty($detail_skills)) {?>	
                                <div class="col-lg-12 lusitana detail-address padding-none">
                                    <?php print $detail_client;?>
                                    <?php print $detail_website;?>
                                    <?php print $detail_category;?>
                                    <?php print $detail_skills;?>
                                </div>
                                <?php }?>
							</div>
						</div>
						<div class="col-lg-9 col-md-8 col-sm-8 padding-right">
                        
							<?php
                               
                            if ($carusel_slider_images) {
                                $is_explode_images = mi_is_explodable($carusel_slider_images);
                                if ($is_explode_images || is_numeric($carusel_slider_images) ) {
                                  $exploded_images = explode(',', $carusel_slider_images); 
                            
									  foreach ($exploded_images as $image) : 
									  
										$attachment_id = $image;
										$image_attributes = wp_get_attachment_image_src( $attachment_id, 'full' );
										$thumbnail_alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
										$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; ?>
            
											<img src="<?php echo esc_attr($image_attributes[0]);?>" <?php print $alt; ?> />
					
									  <?php endforeach;

                                }
                            }
                            ?>
							<div class="clearfix"></div>
						</div>
						
						<div class="clearfix"></div>
					</div>
				</div>
				   
			</div>
		
			<button type="button" class="black-close" data-dismiss="modal"><i class="fa fa-times"></i></button>
		  
		
		</div>
		<!-- /modal-content -->
	</div>
	<!-- /modal-dialog -->
</div>
<!-- /modal -->

<!--/IMAGE INFO-->
