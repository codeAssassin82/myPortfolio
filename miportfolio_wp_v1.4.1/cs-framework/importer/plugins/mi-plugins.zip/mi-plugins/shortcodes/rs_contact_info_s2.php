<?php
/**
 *
 * Contact info
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_contact_info_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'title'           => '',
	'link'            => '',
	'label'           => '',
	'target'          => '',
	'align'           => '',
  ), $atts ) );

 ob_start(); 
 
	if ($target == 'blank') {$target_blank = 'target="_blank"';} else {$target_blank = '';}
	if ($align == 'center') {$align = 'align-center';} else {$align = '';}

	$output   =  '<div class="contact-info '.$align.'"><p>'.$title.'';
	if (!empty($link)){
		$output  .=  '<a href="'. $link .'" '.$target_blank.'> '.$label.'</a>';
	} else {
		$output  .=  $label;
	} 
	$output  .=  '</p></div>';
	
	return $output;

}
add_shortcode( 'mi_contact_info_s2', 'mi_contact_info_s2' );
