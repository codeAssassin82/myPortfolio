<?php
/**
 *
 * RS Portfolio Style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */

function mi_portfolio_s1( $atts, $content = '', $id = '' ) {
  extract( shortcode_atts( array(
    'id'              		=> '',
    'class'         	  	=> '',
  ), $atts ) );


    $output    =  '<section class="sec_2 '.$class.'">';
    $output   .=  do_shortcode($content);
    $output   .=  '</section>';


	return $output;
}
add_shortcode( 'mi_portfolio_s1', 'mi_portfolio_s1' );


function mi_portfolio_item( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              		=> '',
    'class'         	  	=> '',
	'type'      	    	=> '',
	'thumbnail'          	=> '',
	'title'           		=> '',
	'carusel_slider_images' => '',
	's_description'			=> '',
	'description'           => '',
	'client'           		=> '',
	'website'           	=> '',
	'category'           	=> '',
	'skills'           		=> '',
	'vimeo_video'           => '',
  ), $atts ) );


	$item_title	= ( !empty($title)) ? '<h3>'.$title.'</h3>':''; 
	
	$thumbnail_id = $thumbnail;
	$thumbnail_attributes = wp_get_attachment_image_src( $thumbnail_id, 'full' );
	$thumbnail_alt = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
	$alt	= ( !empty($thumbnail_alt)) ? 'alt="'.$thumbnail_alt.'"':''; 

	ob_start();
	
		
	global $imageShortcode;
	$imageShortcode++;
	$image_info_id =  $imageShortcode; ?>
	
	<div class="portfolio-wrap">
		<?php
        $website_style = cs_get_option( 'website_style' );
        if ($website_style == 'website-1' || $website_style == 'website-2') {
             if ($type == 'carousel_slider')	{	require('portfolio/inc_carousel_slider_s1.php');
             } elseif ($type == 'vimeo_video')	{	require('portfolio/inc_vimeo_video_s1.php');
             } elseif ($type == 'flex_slider')	{	require('portfolio/inc_flex_slider_s1.php');
             } elseif ($type == 'image-gallery'){ 	require('portfolio/inc_image_gallery_s1.php');
             } elseif ($type == 'image_info')	{ 	require('portfolio/inc_info_s1.php');}
        } else {
		print "<div class='section-alert'>This unit is not supported by the chosen style of the site. Please replace this unit in the control panel.</div>";
		}
        ?>
	</div>
	
	<?php return ob_get_clean();
}
add_shortcode( 'mi_portfolio_item', 'mi_portfolio_item' );