<?php
/**
 *
 * Icon Style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_icon_s1( $atts, $content = '', $id = '' ) {
  
  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'title'           => '',
	'icon'            => '',
	'icon_color'      => '',
  ), $atts ) );

	$icon_color		= ( !empty($icon_color)) ? 'style="color:'.$icon_color.';"':'';
	$title 			= ( !empty($title)) ? '<h3 class="icon-tag">'.$title.'</h3>':'';

    $output  =  '<div class="icons-row-1">';
    $output .=  '<span class="'.$icon.' icons-edit" '.$icon_color.'></span>';
    $output .=  $title;
    $output .=  '</div>';


  return $output;

}
add_shortcode( 'mi_icon_s1', 'mi_icon_s1' );
