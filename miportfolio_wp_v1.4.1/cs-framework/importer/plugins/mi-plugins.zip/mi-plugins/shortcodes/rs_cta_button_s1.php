<?php
/**
 *
 * CALL TO ACTION BUTTON Style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_cta_button_s1( $atts, $content = '', $id = '' ) {
  
  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'description'     => '',
	'label'           => '',
	'target'          => '',
	'link'            => '',
	'icon'			  => ''
  ), $atts ) );

	$description	= ( !empty($description)) ? '<h4>'.$description.'</h4>':'';
	$icon			= ( !empty($icon)) ? '<span class="'.$icon.'"></span>':'';
	if ($target == 'blank') {$target_blank = 'target="_blank"';} else {$target_blank = 'target="_self"';}
	
	ob_start(); ?>
	
	<section class="sec_3 p-footer">
		<div class="align-center">
			<?php print $icon;?>
			<?php print $description;?>
			<div class="col-lg-6 btn-sec align-center">
				<?php print '<a class="col-lg-2 btn-effect align-center f-download" href="'.$link.'" '.$target_blank.'>'.$label.'</a>';?>
			</div>
		</div>
	</section>
    
	
	<?php

	return ob_get_clean();

}
add_shortcode( 'mi_cta_button_s1', 'mi_cta_button_s1' );
