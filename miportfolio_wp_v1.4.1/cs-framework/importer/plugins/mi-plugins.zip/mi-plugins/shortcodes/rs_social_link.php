<?php
/**
 *
 * Social link
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_social_link( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'title'           => '',
	'facebook'        => '',
	'twitter'         => '',
	'linkedin'        => '',
	'dribble'         => '',
	'youtube'         => '',
	'pinterest'       => '',
	'google'          => ''
  ), $atts ) );


	$website_style = cs_get_option( 'website_style' );
	if ($website_style == 'website-2') {
		$output    =  "<div class='section-alert'>This unit is not supported by the chosen style of the site. Please replace this unit in the control panel.</div>";
	} else {

    //Social Icons
    $output    =  '<div class="social-icon align-center">';
    $output   .=  '<nav>';
	$output   .=  ( !empty($facebook)) 	? '<a class="fb" href="'.$facebook.'" target="_blank" >Facebook</a>':'';
    $output   .=  ( !empty($twitter)) 		? '<a class="twitter" href="'.$twitter.'" target="_blank" >Twitter</a>':'';
    $output   .=  ( !empty($linkedin)) 	? '<a class="linkedin" href="'.$linkedin.'" target="_blank" >Linkedin</a>':'';
    $output   .=  ( !empty($dribble)) 		? '<a class="dribbble" href="'.$dribble.'" target="_blank" >Dribbble</a>':'';
    $output   .=  '</nav>';
    $output   .=  '</div>';
    // End Social Icons
	
	}

	return $output;

}
add_shortcode( 'mi_social_link', 'mi_social_link' );
