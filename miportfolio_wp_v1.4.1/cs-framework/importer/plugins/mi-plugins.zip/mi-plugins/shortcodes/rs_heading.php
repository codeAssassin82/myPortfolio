<?php
/**
 *
 * Heading
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_heading( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'heading'         => '',
    'title_color'     => '',
    'page_name'       => ''
  ), $atts ) );

 
  if (!empty($title_color)) {$tcolor = 'style="color:'.$title_color.'"';} else {$tcolor = '';}
  
  $output  =  '<div class="align-center">';
  $output .=  '<h3 '. $tcolor.'>'.$heading.'</h3>';
  $output .=  '<div class="hr-seperator align-center"></div>';
  $output .=  '</div>';
  $output .=  '<div class="align-center lusitana desc-text ">'.do_shortcode($content).'</div>';


  return $output;

}
add_shortcode( 'mi_heading', 'mi_heading' );
