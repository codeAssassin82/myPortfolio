<?php
/**
 *
 * Button Style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_button_s1( $atts, $content = '', $id = '' ) {
  
  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'label'           => '',
	'target'          => '',
	'link'            => '',
  ), $atts ) );

	if ($target == 'blank') {$target_blank = 'target="_blank"';} else {$target_blank = 'target="_self"';}
	
	$output	 = 	'<a class="col-lg-2 downld-resume lusitana btn-effect-resume align-center" '.$target_blank.' href="'.$link.'">'.$label.'</a>';

	return $output;

}
add_shortcode( 'mi_button_s1', 'mi_button_s1' );
