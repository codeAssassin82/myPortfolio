<?php
/**
 *
 * Social link
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_social_link_s2( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
	'title'           => '',
	'facebook'        => '',
	'twitter'         => '',
	'linkedin'        => '',
	'dribble'         => '',
	'youtube'         => '',
	'pinterest'       => '',
	'google'          => ''
  ), $atts ) );

 ob_start(); ?>

    <!-- Social Icons -->
    <div class="social-icons">
   	    <?php if (!empty($facebook)) {?>
        <div class="facebook col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <a href="<?php echo esc_attr($facebook);?>" target="_blank">   <!--Facebook Link goes inside href -->
                <span class="social-icon align-center">
                    <span class="facebook-line">Facebook</span>
                    <span class="icon-facebook show-on-mobile"></span>
                </span>
            </a>
        </div>
        <?php } if (!empty($twitter)) {?>
        <div class="tweeter col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <a href="<?php echo esc_attr($twitter);?>" target="_blank"> <!--Twitter Link goes inside href -->
            <span class="social-icon align-center">
                <span class="twitter-line">Twitter</span>
                <span class="icon-twitter  show-on-mobile"></span>
            </span>
            </a>
        </div>
        <?php } if (!empty($linkedin)) {?>
        <div class="linkedin col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <a href="<?php echo esc_attr($linkedin);?>" target="_blank"> <!--Linkedin Link goes inside href -->
                <span class="social-icon align-center">
                    <span class="linkedin-line">Linkedin</span>
                    <span class=" icon-linkedin   show-on-mobile"></span>
                </span>
            </a>
        </div>
        <?php } if (!empty($dribble)) {?>
        <div class="dribble col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <a href="<?php echo esc_attr($dribble);?>" target="_blank"> <!--Dribbble Link goes inside href -->
                <span class="social-icon align-center">
                    <span class="dribble-line">Dribbble</span>
                    <span class="icon-dribbble show-on-mobile"></span>
                </span>
            </a>
        </div>
        <?php }?>
    </div>
    <!-- /Social Icons -->

 <?php return ob_get_clean();

}
add_shortcode( 'mi_social_link_s2', 'mi_social_link_s2' );
