<?php
/**
 *
 * Fullscreen Landing
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_fullscreen_landing( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
  	'title'           => '',
  	'description'     => ''
  ), $atts ) );

	$output    =  '<section class="autoheight">';
	$output   .=  '<div class="animate-landing"></div>';
    $output   .=  '<div class="col-lg-12 landing-text-pos wow fadeInUp animated" data-wow-duration="1s" data-wow-delay="3s">';
		if (!empty($title)) {
			$output   .=  '<span class="landing-pname align-center">'.$title.'</span>';
			$output   .=  '<hr id="title_hr">';
		}
		if (!empty($description)) {
			$output   .=  '<span class="col-lg-6 landing-intro align-center lusitana">'.$description.'</span>';
		}
    $output   .=  '</div>';
    $output   .=  '</section>';

	return $output;

}
add_shortcode( 'mi_fullscreen_landing', 'mi_fullscreen_landing' );
