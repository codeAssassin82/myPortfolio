<?php
/**
 *
 * Heading Style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function mi_heading_s1( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'heading'         => '',
    'description'     => '',
    'title_color'     => '',
  	'desc_color'	  => '',
  	'sep_color'	 	  => ''
	
  ), $atts ) );

 
  if (!empty($title_color)) {$tcolor = 'style="color:'.$title_color.'"';} else {$tcolor = '';}
  if (!empty($desc_color))  {$tdesc_color = 'style="color:'.$desc_color.'"';} else {$tdesc_color = '';}
  if (!empty($sep_color))  {$tsep_color = 'style="background-color:'.$sep_color.'"';} else {$tsep_color = '';}
  if (!empty($description)) {$content_is = '<h4 '.$tdesc_color.'>'.$description.'</h4>';} else {$content_is = '';}
  
	ob_start(); ?>

    <div class="align-center heading-wrap">
        <?php print '<h3 '.$tcolor.'>'.$heading.'</h3>';?>
        <div class="hr-seperator align-center" <?php print $tsep_color;?>></div>
        <?php print $content_is;?>
    </div>


  <?php return ob_get_clean();

}
add_shortcode( 'mi_heading_s1', 'mi_heading_s1' );
