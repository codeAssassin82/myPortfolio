<?php
/**
  * WPBakery Visual Composer Shortcodes settings
  *
  * @package VPBakeryVisualComposer
  *
 */

// Include Helpers
//include_once( T_PATH . '/' . F_DIR . '/composer/helpers.php' );
include_once( EF_ROOT . '/composer/params.php' );

if ( ! function_exists( 'is_plugin_active' ) ) {
  include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
}

/////////////////////////////////////////////////////////////////////////////////////////////
///Style 1
/////////////////////////////////////////////////////////////////////////////////////////////

// FULLSCREEN LANDING STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Fullscreen landing style 1',
  'base'            => 'mi_fullscreen_landing_s1',
  'category'        => 'style1',
  'icon'            => '',
  'description'     => 'Text with Icon',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
	  'type'        => 'attach_image',
	  'heading'     => 'Background image',
	  'param_name'  => 'bg_image',
	  'admin_label' => true
	),
  )

) );

// HEADING STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Heading style 1',
  'base'            => 'mi_heading_s1',
  'category'        => 'style1',
  'icon'            => '',
  'description'     => 'Custom Heading',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Heading *',
      'param_name'  => 'heading',
      'admin_label' => true
    ),
    array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select title color',
      'param_name'  => 'title_color',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select description color',
      'param_name'  => 'desc_color',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select separate color',
      'param_name'  => 'sep_color',
    ),

  )

) );

// PORTOFOLIO STYLE 1
// ==========================================================================================

vc_map( array(
  'name'            => 'Portfolio style 1',
  'base'            => 'mi_portfolio_s1',
  'category'        => 'style1',
  'as_parent'       => array('only' => 'mi_portfolio_item'),
  'content_element' => true,
  'show_settings_on_create' => false,
  'icon'            => '',
  'js_view'                 => 'VcColumnView',
  'std'         => '',
  'description' => 'Select pages you want to display this shortcode on.',
  'params' => array(
	  array(
		  'type'        => 'textfield',
		  'heading'     => 'Extra class name',
		  'param_name'  => 'class',
		  'description' => 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.',
		  'admin_label' => true
		),
	)
) );

vc_map( array(
    'name' => __('Portfolio Item'),
    'base' => 'mi_portfolio_item',
    'as_child' => array('only' => 'mi_portfolio_s1'),
    'content_element' => true,
    'params' => array(
        array(
          'type'        => 'dropdown',
          'heading'     => 'Choose Item Type',
          'param_name'  => 'type',
          'value'       => array(
		  	'Carousel Slider'	=> 'carousel_slider',
			'Vimeo Video'		=> 'vimeo_video',
			'Flex Slider'		=> 'flex_slider',
			'Image Gallery'		=> 'image-gallery',
			'Image & Info'		=> 'image_info',
			)
        ),
		array(
		  'type'        => 'attach_image',
		  'heading'     => 'Thumbnail image',
		  'param_name'  => 'thumbnail',
		  'admin_label' => false
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Title',
		  'param_name'  => 'title',
		  'admin_label' => true
		),
		array(
		  'type'        => 'textarea',
		  'heading'     => 'Short Description',
		  'param_name'  => 's_description',
		  'admin_label' => false,
		),
		
		//CAROUSEL SLIDER IMAGE, FLEX SLIDER IMAGE, GALLERY IMAGES, INFO IMAGES
		array(
		  'type'        => 'attach_images',
		  'heading'     => 'Slider images',
		  'param_name'  => 'carusel_slider_images',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'flex_slider', 'image-gallery', 'image_info') ),
		),
		array(
		  'type'        => 'textarea',
		  'heading'     => 'Description',
		  'param_name'  => 'description',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'flex_slider', 'vimeo_video', 'image_info') ),
		),
		//META
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Client',
		  'param_name'  => 'client',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Website',
		  'param_name'  => 'website',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Category',
		  'param_name'  => 'category',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Skills',
		  'param_name'  => 'skills',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		//VIMEO VIDEO
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Vimeo Video URL',
		  'param_name'  => 'vimeo_video',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('vimeo_video') ),
		  'value' => '',
		),
    )
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Mi_Portfolio_S1 extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Mi_Portfolio_Item extends WPBakeryShortCode {
    }
}

// CALL TO ACTION BUTTON STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Call to action button style 1',
  'base'            => 'mi_cta_button_s1',
  'category'        => 'style1',
  'icon'            => '',
  'description'     => 'Button with Text',
  'params'          => array(
	array(
      'type'        => 'textfield',
      'heading'     => 'Icon',
      'param_name'  => 'icon',
      'value'       => 'icon-flag',
      'description' => 'Enter the name of the icon. List icons http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website#codes'
    ),	
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the description'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button label',
      'param_name'  => 'label',
      'value'       => 'Download',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Button link',
      'param_name'  => 'link',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
  )

) );

// BUTTON STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Button style 1',
  'base'            => 'mi_button_s1',
  'category'        => 'style1',
  'icon'            => '',
  'description'     => 'Simple Button',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Button label',
      'param_name'  => 'label',
      'value'       => 'Download',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Button link',
      'param_name'  => 'link',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
  )

) );

// ICON STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Icon style 1',
  'base'            => 'mi_icon_s1',
  'category'        => 'style1',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
	  'admin_label' => true,
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Icon',
      'param_name'  => 'icon',
      'value'       => 'icon-tools',
      'description' => 'Enter the name of the icon. List icons http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website#codes'
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Icon color',
      'param_name'  => 'icon_color',
      'value'       => '',
    ),
  )

) );

// CONTACT INFO STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Contact info style 1',
  'base'            => 'mi_contact_info_s1',
  'category'        => 'style1',
  'icon'            => '',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title (Optional)',
      'param_name'  => 'title',
    ),
	array(
      'type'        	=> 'textfield',
      'heading'     	=> 'Link (Optional)',
      'param_name'  	=> 'link',
	  'description'     => 'Example: callto:48501278364, mailto:hello@myname.com, http://google.com',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Label',
      'param_name'  => 'label',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
	array(
      'type'        => 'dropdown',
      'heading'     => 'Text align',
      'param_name'  => 'align',
      'value'       => array(
        'Center'	=>  'center',
        'Left'      =>  'left',
      )
    ),
  )

) );

// SOCIAL LINK STYLE 1
// ==========================================================================================
vc_map( array(
  'name'            => 'Social link style 1',
  'base'            => 'mi_social_link_s1',
  'category'        => 'style1',
  'icon'            => '',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Facebook',
      'param_name'  => 'facebook',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Twitter',
      'param_name'  => 'twitter',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Linkedin',
      'param_name'  => 'linkedin',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Dribbble',
      'param_name'  => 'dribble',
	  'description' => 'Leave blank to hide'
    ),
  )

) );

/////////////////////////////////////////////////////////////////////////////////////////////
///Style 2
/////////////////////////////////////////////////////////////////////////////////////////////

// FULLSCREEN LANDING STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Fullscreen landing style 2',
  'base'            => 'mi_fullscreen_landing_s2',
  'category'        => 'style2',
  'icon'            => '',
  'description'     => 'Text with Icon',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
	  'type'        => 'attach_image',
	  'heading'     => 'Background image',
	  'param_name'  => 'bg_image',
	  'admin_label' => true
	),
  )

) );

// HEADING STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Heading style 2',
  'base'            => 'mi_heading_s2',
  'category'        => 'style2',
  'icon'            => '',
  'description'     => 'Custom Heading',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'heading',
	  'description' => 'Leave blank to hide title',
      'admin_label' => true
    ),
    array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
	  'description' => 'Leave blank to hide the description',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select title color',
      'param_name'  => 'title_color',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Enter title font size',
      'param_name'  => 'title_font_size',
	  'description' => 'Example: 1.5em, 14px',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select description color',
      'param_name'  => 'desc_color',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Enter description font size',
      'param_name'  => 'desc_font_size',
	  'description' => 'Example: 1.5em, 14px',
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select separate color',
      'param_name'  => 'sep_color',
    ),

  )

) );

// CALL TO ACTION BUTTON STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Call to action button style 2',
  'base'            => 'mi_cta_button_s2',
  'category'        => 'style2',
  'icon'            => '',
  'description'     => 'Button with Text',
  'params'          => array(
	array(
      'type'        => 'textfield',
      'heading'     => 'Icon',
      'param_name'  => 'icon',
      'value'       => 'icon-flag',
      'description' => 'Enter the name of the icon. List icons http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website#codes'
    ),	
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the description'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button label',
      'param_name'  => 'label',
      'value'       => 'Download',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Button link',
      'param_name'  => 'link',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
  )

) );

// BUTTON STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Button style 2',
  'base'            => 'mi_button_s2',
  'category'        => 'style2',
  'icon'            => '',
  'description'     => 'Simple Button',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Button label',
      'param_name'  => 'label',
      'value'       => 'Download',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Button link',
      'param_name'  => 'link',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
  )

) );

// ICON STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Icon style 2',
  'base'            => 'mi_icon_s2',
  'category'        => 'style2',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
	  'admin_label' => true,
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Icon',
      'param_name'  => 'icon',
      'value'       => 'icon-tools',
      'description' => 'Enter the name of the icon. List icons http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website#codes'
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Icon color',
      'param_name'  => 'icon_color',
      'value'       => '',
    ),
  )

) );

// CONTACT INFO STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Contact info style 2',
  'base'            => 'mi_contact_info_s2',
  'category'        => 'style2',
  'icon'            => '',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title (Optional)',
      'param_name'  => 'title',
    ),
	array(
      'type'        	=> 'textfield',
      'heading'     	=> 'Link (Optional)',
      'param_name'  	=> 'link',
	  'description'     => 'Example: callto:48501278364, mailto:hello@myname.com, http://google.com',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Label',
      'param_name'  => 'label',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
	array(
      'type'        => 'dropdown',
      'heading'     => 'Text align',
      'param_name'  => 'align',
      'value'       => array(
        'Center'	=>  'center',
        'Left'      =>  'left',
      )
    ),
  )

) );

// SOCIAL LINK STYLE 2
// ==========================================================================================
vc_map( array(
  'name'            => 'Social link style 2',
  'base'            => 'mi_social_link_s2',
  'category'        => 'style2',
  'icon'            => '',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Facebook',
      'param_name'  => 'facebook',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Twitter',
      'param_name'  => 'twitter',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Linkedin',
      'param_name'  => 'linkedin',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Dribbble',
      'param_name'  => 'dribble',
	  'description' => 'Leave blank to hide'
    ),
  )

) );

/////////////////////////////////////////////////////////////////////////////////////////////
///Style 4-6
/////////////////////////////////////////////////////////////////////////////////////////////

// FULLSCREEN LANDING
// ==========================================================================================
vc_map( array(
  'name'            => 'Fullscreen landing',
  'base'            => 'mi_fullscreen_landing',
  'icon'            => '',
  'description'     => 'Text with Icon',
  'category'		=> 'style3',

  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
  )

) );


// TEXT WITH ICON     
// ==========================================================================================
vc_map( array(
  'name'            => 'Icon Text',
  'base'            => 'mi_text_icon',
  'icon'            => '',
  'description'     => 'Text with Icon',
  'category'		=> 'style3',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title',
      'param_name'  => 'title',
      'admin_label' => true,
      'value'       => '',
      'description' => 'Leave blank to hide the title'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Icon',
      'param_name'  => 'icon',
      'value'       => 'icon-tools',
      'description' => 'Enter the name of the icon. List icons http://www.elegantthemes.com/blog/resources/how-to-use-and-embed-an-icon-font-on-your-website#codes'
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Icon color',
      'param_name'  => 'icon_color',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Icon position',
      'param_name'  => 'icon_position',
      'value'       => array(
        'Left'      =>  'left',
        'Top'       =>  'top',
      )
    ),
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'value'       => '',
      'description' => 'Leave blank to hide the description'
    ),
  )

) );

// CALL TO ACTION BUTTON
// ==========================================================================================
vc_map( array(
  'name'            => 'Call to action button',
  'base'            => 'mi_cta_button',
  'icon'            => '',
  'description'     => 'Button with Text',
  'category'		=> 'style3',
  'params'          => array(
	array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'admin_label' => true,
      'value'       => '',
      'description' => 'Leave blank to hide the description'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button label',
      'param_name'  => 'label',
      'value'       => 'Download',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Button link',
      'param_name'  => 'link',
      'value'       => '',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
  )

) );

// PORTOFOLIO Style 3
// ==========================================================================================
vc_map( array(
    'name' => __('Portfolio Style 3'),
    'base' => 'mi_portfolio_s3',
    'content_element' => true,
	'category'		=> 'style3',
    'params' => array(
        array(
          'type'        => 'dropdown',
          'heading'     => 'Choose Item Type',
          'param_name'  => 'type',
          'value'       => array(
		  	'Carousel Slider'	=> 'carousel_slider',
			'Vimeo Video'		=> 'vimeo_video',
			'Flex Slider'		=> 'flex_slider',
			'Image Gallery'		=> 'image-gallery',
			'Image & Info'		=> 'image_info',
			)
        ),
		array(
		  'type'        => 'attach_image',
		  'heading'     => 'Thumbnail image',
		  'param_name'  => 'thumbnail',
		  'admin_label' => false,
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Title',
		  'param_name'  => 'title',
		  'admin_label' => true
		),
		//CAROUSEL SLIDER IMAGE, FLEX SLIDER IMAGE, GALLERY IMAGES, INFO IMAGES
		array(
		  'type'        => 'attach_images',
		  'heading'     => 'Slider images',
		  'param_name'  => 'carusel_slider_images',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'flex_slider', 'image-gallery', 'image_info') ),
		),
		array(
		  'type'        => 'textarea',
		  'heading'     => 'Description',
		  'param_name'  => 'description',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'flex_slider', 'vimeo_video', 'image_info') ),
		),
		//META
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Client',
		  'param_name'  => 'client',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Website',
		  'param_name'  => 'website',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Category',
		  'param_name'  => 'category',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Skills',
		  'param_name'  => 'skills',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('carousel_slider', 'image_info', 'vimeo_video') ),
		),
		//VIMEO VIDEO
		array(
		  'type'        => 'textfield',
		  'heading'     => 'Vimeo Video URL',
		  'param_name'  => 'vimeo_video',
		  'admin_label' => false,
		  'dependency'  => array( 'element' => 'type', 'value' => array('vimeo_video') ),
		  'value' => '',
		),
    )
) );


// CONTACT INFO  
// ==========================================================================================
vc_map( array(
  'name'            => 'Contact info',
  'base'            => 'mi_contact_info',
  'icon'            => '',
  'category'		=> 'style3',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Title (Optional)',
      'param_name'  => 'title',
      'admin_label' => true,
    ),
	array(
      'type'        	=> 'textfield',
      'heading'     	=> 'Link (Optional)',
      'param_name'  	=> 'link',
	  'description'     => 'Example: callto:48501278364, mailto:hello@myname.com, http://google.com',
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Label',
      'param_name'  => 'label',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Target',
      'param_name'  => 'target',
      'value'       => array(
        'Open link in new window'		=>  'blank',
        'Open link in same window'      =>  'same',
      )
    ),
	array(
      'type'        => 'dropdown',
      'heading'     => 'Text align',
      'param_name'  => 'align',
      'value'       => array(
        'Center'	=>  'center',
        'Left'      =>  'left',
      )
    ),
  )

) );

// SOCIAL LINK 
// ==========================================================================================
vc_map( array(
  'name'            => 'Social link',
  'base'            => 'mi_social_link',
  'icon'            => '',
  'category'		=> 'style3',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Facebook',
      'param_name'  => 'facebook',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Twitter',
      'param_name'  => 'twitter',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Linkedin',
      'param_name'  => 'linkedin',
	  'description' => 'Leave blank to hide'
    ),
	array(
      'type'        => 'textfield',
      'heading'     => 'Dribbble',
      'param_name'  => 'dribble',
	  'description' => 'Leave blank to hide'
    ),
  )

) );

// HEADING
// ==========================================================================================
vc_map( array(
  'name'            => 'Heading',
  'base'            => 'mi_heading',
  'icon'            => '',
  'description'     => 'Custom Heading',
  'category'		=> 'style3',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Heading',
      'param_name'  => 'heading',
      'admin_label' => true,
    ),
	array(
      'type'        => 'colorpicker',
      'heading'     => 'Select title color',
      'param_name'  => 'title_color',
    ),
    array(
      'type'        => 'textarea_html',
      'heading'     => 'Content',
      'param_name'  => 'content',
    ),
  )

) );

// ROW CUSTOM
// ==========================================================================================
vc_map( array(
	'name' => __( 'Row', 'js_composer' ),
	'base' => 'vc_row',
	'is_container' => true,
	'icon' => 'icon-wpb-row',
	'show_settings_on_create' => false,
	'category' => __( 'Content', 'js_composer' ),
	'description' => __( 'Place content elements inside the row', 'js_composer' ),
	'params' => array(
		array(
			'type' => 'dropdown',
			'heading' => 'Row stretch',
			'param_name' => 'full_width',
			'value' => array(
				'Default' => '',
				'Full width' => 'stretch_row',
			),
			'description' => __( 'Select stretching options for row and content. Stretched row overlay sidebar and may not work if parent container has overflow: hidden css property.', 'js_composer' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'js_composer' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
		),
		array(
			'type' => 'css_editor',
			'heading' => __( 'Css', 'js_composer' ),
			'param_name' => 'css',
			'group' => __( 'Design options', 'js_composer' )
		),

        array(
          'type'        => 'dropdown',
          'heading'     => 'Choose Background Type',
		  'admin_label' => false,
          'param_name'  => 'type_bg',
		  'group' 		=> 'Additional background',
          'value'       => array(
		  	''					=> '',
			'Video background'	=> 'video_bg',
			'Slider background'	=> 'slider_bg',
			)
        ),
		array(
			'type' => 'textfield',
			'heading' => __( 'MP4 file' ),
			'param_name' => 'mp4_video_url',
			'description' => 'Insert a link to a video in mp4 format',
			'admin_label' => false,
			'group' => __( 'Additional background', 'js_composer' ),
			'dependency' => array(
				'element' 	=> 'type_bg',
				'value' 	=> array('video_bg'),
			)
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'OGG file' ),
			'param_name' => 'ogg_video_url',
			'description' => 'Insert a link to a video in ogg format',
			'admin_label' => false,
			'group' => __( 'Additional background', 'js_composer' ),
			'dependency' => array(
				'element' 	=> 'type_bg',
				'value' 	=> array('video_bg'),
			)
		),
		array(
		  'type'        => 'attach_images',
		  'heading'     => 'Slider images',
		  'param_name'  => 'bg_slider_images',
		  'group' => __( 'Additional background', 'js_composer' ),
		  'admin_label' => false,
		  'dependency' => array(
				'element' 	=> 'type_bg',
				'value' 	=> array('slider_bg'),
			)
		),
		

		

	),
	'js_view' => 'VcRowView'
) );


/***Global ID Image $ Info Block***************/

add_action( 'admin_init', 'vc_remove_elements', 10);
function vc_remove_elements( $e = array() ) {

  if ( !empty( $e ) ) {
    foreach ( $e as $key => $r_this ) {
      vc_remove_element( 'vc_'.$r_this );
    }
  }
}

$s_elemets = array( 'tabs', 'tab', 'accordion', 'accordion_tab', 'custom_heading', 'empty_space', 'clients', 'column_text', 'widget_sidebar', 'toggle', 'images_carousel', 'carousel', 'tour', 'gallery', 'posts_slider', 'posts_grid', 'teaser_grid', 'separator', 'text_separator', 'message', 'facebook', 'tweetmeme', 'googleplus', 'pinterest', 'single_image', 'button', 'toogle', 'button2', 'cta_button', 'cta_button2', 'video', 'gmaps', 'flickr', 'progress_bar', 'raw_html', 'raw_js', 'pie', 'wp_search', 'wp_meta', 'wp_recentcomments', 'wp_calendar', 'wp_pages', 'wp_custommenu', 'wp_text', 'wp_posts', 'wp_links', 'wp_categories', 'wp_archives', 'wp_rss', 'wp_tagcloud', 'basic_grid', 'media_grid', 'masonry_grid', 'icon', 'masonry_media_grid' );
vc_remove_element('client', 'testimonial', 'contact-form-7');
vc_remove_elements( $s_elemets );