"use strict";
jQuery(function($){
		    });
